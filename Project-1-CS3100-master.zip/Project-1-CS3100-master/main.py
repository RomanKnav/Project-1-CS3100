import curses
import fileReader2 
import UI


curses.wrapper(UI.main)
